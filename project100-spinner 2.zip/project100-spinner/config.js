module.exports = {
  mongoURI: "mongodb://admin:admin@ds145669.mlab.com:45669/project100"
}
